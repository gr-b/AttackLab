/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_423(unsigned x)
{
    return x + 3284650312U;
}

unsigned getval_116()
{
    return 2425378831U;
}

unsigned getval_285()
{
    return 3284633928U;
}

unsigned getval_159()
{
    return 365123686U;
}

void setval_424(unsigned *p)
{
    *p = 851677784U;
}

void setval_173(unsigned *p)
{
    *p = 3281031192U;
}

unsigned getval_148()
{
    return 3347663460U;
}

unsigned addval_466(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_357(unsigned *p)
{
    *p = 3285090763U;
}

void setval_425(unsigned *p)
{
    *p = 3286272360U;
}

unsigned getval_288()
{
    return 3767076933U;
}

unsigned addval_232(unsigned x)
{
    return x + 3286276424U;
}

void setval_123(unsigned *p)
{
    *p = 3284306399U;
}

unsigned addval_404(unsigned x)
{
    return x + 3285289411U;
}

unsigned addval_431(unsigned x)
{
    return x + 3281047177U;
}

unsigned getval_441()
{
    return 3525889673U;
}

unsigned getval_147()
{
    return 3524841865U;
}

unsigned getval_231()
{
    return 3352398276U;
}

unsigned addval_172(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_373()
{
    return 3229929897U;
}

void setval_167(unsigned *p)
{
    *p = 3767093487U;
}

unsigned getval_360()
{
    return 3534016905U;
}

unsigned addval_479(unsigned x)
{
    return x + 3687105161U;
}

unsigned addval_197(unsigned x)
{
    return x + 3380134537U;
}

unsigned addval_156(unsigned x)
{
    return x + 3374894729U;
}

unsigned getval_253()
{
    return 2447411528U;
}

void setval_131(unsigned *p)
{
    *p = 3376991881U;
}

unsigned addval_263(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_449()
{
    return 3223896713U;
}

unsigned getval_343()
{
    return 3380924041U;
}

void setval_432(unsigned *p)
{
    *p = 3372794505U;
}

void setval_124(unsigned *p)
{
    *p = 3531919753U;
}

void setval_300(unsigned *p)
{
    *p = 3286280520U;
}

unsigned addval_149(unsigned x)
{
    return x + 3526939081U;
}

unsigned addval_272(unsigned x)
{
    return x + 3525362345U;
}

unsigned addval_319(unsigned x)
{
    return x + 3375940297U;
}

void setval_135(unsigned *p)
{
    *p = 3523268233U;
}

void setval_202(unsigned *p)
{
    *p = 3677930185U;
}

unsigned getval_154()
{
    return 3352201570U;
}

unsigned addval_421(unsigned x)
{
    return x + 3524841865U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
